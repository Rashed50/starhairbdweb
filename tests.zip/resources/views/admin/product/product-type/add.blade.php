@extends('layouts.adminLayout.master')

@section('content')

<div class="col-12 col-sm-12 col-md-8 col-lg-9 col-xl-10 bg-faded py-3">
    <hr>
    <h1 class="">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>

        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        @if(Session::has('success'))
                            <div class="alert alert-success alertsuccess">
                                <strong>Success!</strong> {{ Session::get('success') }}
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alerterror">
                                <strong>Success!</strong> {{ Session::get('error') }}
                            </div>
                        @endif
                    </div>
                    <div class="col-md-3"></div>
                    <div class="col-md-3 float-right" style="width: 40px;">{{(@$data)?'Update':'New' }} Product Type Form</div>
                </div>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-8">
                        <form action="{{ (@$data)? route('product-type.update'):route('product-type.store') }}" method="post" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group row {{ $errors->has('')? 'has-error' : 'PTName' }}">
                                <label for="ProductType" class="col-sm-3 col-form-label">Product Type Name :</label>
                                <div class="col-sm-7">
                                <input type="text" class="form-control" name="PTName" value="{{(@$data)? @$data->product_type_name: old('PTName') }}" id="ProductType" placeholder="Product Type Name">
                                <input type="hidden" name="id" value="{{@$data->product_type_id ?? ''}}" id="ProductType" placeholder="Product Type Name">
                                @if($errors->has('PTName'))
                                    <samp class="invalid-feedback" role="alert">
                                        <strong>{{$errors->first('PTName')}}</strong>
                                    </samp>
                                @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="ProductType" class="col-sm-3 col-form-label">Product Type Image :</label>
                                <div class="col-sm-7">
                                <input type="file" class="form-control" name="PTImage"  id="ProductTypeImage">
                                
                                </div>
                            </div>

                            <div class="col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary mb-2">{{ (@$data)? 'UPDATE':'SAVE'}}</button>
                            </div>

                        </form>
                    </div>
                    <div class="col-2"></div>
                </div>
                 
            </div>

            <div class="card-footer">
                
            </div>
            <h3 class="list-header">Product Type List</h3>
        <div class="table-responsive">
            <table id="alltableinfo" class="table table-bordered custom_table mb-0">
                <thead>
                    <tr>
                        <th>Product Type Name</th>
                        <th>Image</th>
                        <th>Manage</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($allType as $item)
                        <tr>
                            <td>{{ $item->product_type_name }}</td>
                            <td> <img height="40" src="{{ asset($item->product_type_photo)}}" alt=""> </td>
                            <td>
                              <a href="{{ route('product-type.edit',$item->product_type_id) }}" class="btn btn-primary mr-2">EDIT</a>
                              <a href="{{ route('product-type.delete',$item->product_type_id) }}" id="confirm" class="btn btn-primary">DELETE</a>

                            </td>
                        </tr>
                    @empty

                    <p style="color:red"> Data Not found </p>
                    @endforelse
                </tbody>

        </div>
        </div>

</div>


@endsection