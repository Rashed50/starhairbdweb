@extends('layouts.website')
@section('contents')

<section id="about">
    <div class="container">
        <div class="row">
            <div class="about-heading text-center">
                <h2>Mission</h2>
                <p><a href="#">home</a> <i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i> <span>Mission</span></p>
            </div>
        </div>
    </div>
</section>
<section id="blog">
    <div class="container">
        <div class="row">
            <div class="heading4 text-center">
                <h2>Mission &  Vision</h2>
            </div>
            <div class="blog-main">
                <div class="col-md-12 col-sm-12">
                    <div class="Privacy" style="border: 1px solid #fafafa;">
                        <div class="card" style="width: 80%; margin: 0 auto;">
                            <div class="card-body" style="margin: 0 auto; padding: 20px; align-items: center; text-align:center">
                                <div class="single-item" style="display: flex;">
                                    <h4 style="padding-right: 15px;">name</h4>
                                    <p style="padding-top: 10px;">nemo vel quae dolores ad totam cupiditate atque ipsa provident, omnis autem eius distinctio deleniti quod odio.</p>
                                </div>
                                <div class="single-item" style="display: flex;">
                                    <h4 style="padding-right: 15px;">name</h4>
                                    <p style="padding-top: 10px;">nemo vel quae dolores ad totam cupiditate atque ipsa provident, omnis autem eius distinctio deleniti quod odio.</p>
                                </div>
                                <div class="single-item" style="display: flex;">
                                    <h4 style="padding-right: 15px;">name</h4>
                                    <p style="padding-top: 10px;">nemo vel quae dolores ad totam cupiditate atque ipsa provident, omnis autem eius distinctio deleniti quod odio.</p>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
@endsection